/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "c83b5cc5ed1f203df622785805d669d9"
  }, {
    "url": "pwa-512x512.png",
    "revision": "a5c505dd5b8e2eaf9527abab1b0f2b74"
  }, {
    "url": "pwa-192x192.png",
    "revision": "a68be824f1924240798c77138003081e"
  }, {
    "url": "index.html",
    "revision": "d4d7475e80cd12ce9a7fca6b1fb1b3aa"
  }, {
    "url": "icon.svg",
    "revision": "5b53e4e7003ecd5c6925efd07be20ec7"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "27638d7a9e0d7b503364e55180bc4098"
  }, {
    "url": "assets/index-CxPXNXrb.css",
    "revision": null
  }, {
    "url": "assets/index-B7XQdIzv.js",
    "revision": null
  }, {
    "url": "assets/aistudio/image_ea36d4c9.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_bc2e25d7.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_af81f185.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "27638d7a9e0d7b503364e55180bc4098"
  }, {
    "url": "icon.svg",
    "revision": "5b53e4e7003ecd5c6925efd07be20ec7"
  }, {
    "url": "pwa-192x192.png",
    "revision": "a68be824f1924240798c77138003081e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "a5c505dd5b8e2eaf9527abab1b0f2b74"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "c83b5cc5ed1f203df622785805d669d9"
  }, {
    "url": "manifest.webmanifest",
    "revision": "060ad66d942e7e9e82235b9614df1bb6"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
