package ch.protonvpn.android.webclone;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final int VPN_REQUEST_CODE = 1001;
    private WebView webView;
    private String pendingServer = "AU#31";
    private String pendingExitIp = "103.107.198.31";
    private String pendingCountry = "Australia";
    private String pendingProtocol = "WireGuard";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.parseColor("#0C0A12"));
            getWindow().setNavigationBarColor(Color.parseColor("#13111C"));
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0C0A12"));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0C0A12"));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= 16) {
            settings.setAllowFileAccessFromFileURLs(true);
            settings.setAllowUniversalAccessFromFileURLs(true);
        }
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= 21) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.addJavascriptInterface(new AndroidVpnBridge(), "AndroidVpnBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(root);

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void prepareAndLaunchVpnService(String serverName, String exitIp, String countryName, String protocol) {
        pendingServer = serverName != null ? serverName : "AU#31";
        pendingExitIp = exitIp != null ? exitIp : "103.107.198.31";
        pendingCountry = countryName != null ? countryName : "Australia";
        pendingProtocol = protocol != null ? protocol : "WireGuard";

        Intent prepareIntent = VpnService.prepare(this);
        if (prepareIntent != null) {
            startActivityForResult(prepareIntent, VPN_REQUEST_CODE);
        } else {
            onActivityResult(VPN_REQUEST_CODE, Activity.RESULT_OK, null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            Intent serviceIntent = new Intent(this, ProtonVpnService.class);
            serviceIntent.setAction(ProtonVpnService.ACTION_CONNECT);
            serviceIntent.putExtra("serverName", pendingServer);
            serviceIntent.putExtra("exitIp", pendingExitIp);
            serviceIntent.putExtra("countryName", pendingCountry);
            serviceIntent.putExtra("protocol", pendingProtocol);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            Toast.makeText(
                this,
                "🔑 Proton VPN Connected: " + pendingCountry + " (" + pendingServer + " · " + pendingExitIp + ")",
                Toast.LENGTH_SHORT
            ).show();
        }
    }

    public class AndroidVpnBridge {
        @JavascriptInterface
        public void startVpn(final String serverName, final String exitIp, final String countryName, final String protocol) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    prepareAndLaunchVpnService(serverName, exitIp, countryName, protocol);
                }
            });
        }

        @JavascriptInterface
        public void stopVpn() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent serviceIntent = new Intent(MainActivity.this, ProtonVpnService.class);
                    serviceIntent.setAction(ProtonVpnService.ACTION_DISCONNECT);
                    startService(serviceIntent);
                    Toast.makeText(MainActivity.this, "Proton VPN Disconnected", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public boolean isVpnActive() {
            return ProtonVpnService.isRunning;
        }

        @JavascriptInterface
        public String fetchTunneledUrl(String targetUrl) {
            try {
                URL url = new URL(targetUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(4500);
                conn.setReadTimeout(4500);
                conn.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13; ProtonVPN-Tunneled) AppleWebKit/537.36 Chrome/126.0.0.0 Mobile Safari/537.36"
                );
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null && sb.length() < 60000) {
                    sb.append(line).append("\n");
                }
                reader.close();
                return sb.toString();
            } catch (Exception e) {
                return "";
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
