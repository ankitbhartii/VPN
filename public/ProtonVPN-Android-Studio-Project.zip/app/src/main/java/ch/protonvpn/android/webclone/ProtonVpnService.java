package ch.protonvpn.android.webclone;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

public class ProtonVpnService extends VpnService implements Runnable {
    public static final String ACTION_CONNECT = "ch.protonvpn.android.webclone.START_VPN";
    public static final String ACTION_DISCONNECT = "ch.protonvpn.android.webclone.STOP_VPN";
    private static final String CHANNEL_ID = "protonvpn_tunnel_channel";
    private static final int NOTIFICATION_ID = 1402;

    public static volatile boolean isRunning = false;
    public static volatile String currentServer = "AU#31";
    public static volatile String currentExitIp = "103.107.198.31";
    public static volatile String currentCountry = "Australia";

    private Thread tunnelThread;
    private ParcelFileDescriptor vpnInterface;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_DISCONNECT.equals(intent.getAction())) {
            stopVpnTunnel();
            return START_NOT_STICKY;
        }

        if (intent != null) {
            String srv = intent.getStringExtra("serverName");
            String ip = intent.getStringExtra("exitIp");
            String country = intent.getStringExtra("countryName");
            if (srv != null && !srv.isEmpty()) currentServer = srv;
            if (ip != null && !ip.isEmpty()) currentExitIp = ip;
            if (country != null && !country.isEmpty()) currentCountry = country;
        }

        startForegroundNotification();
        startVpnTunnel();
        return START_STICKY;
    }

    private void startForegroundNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Proton VPN Tunnel Status",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Active ProTUN WireGuard VPN session");
            nm.createNotificationChannel(channel);
        }

        Intent openIntent = new Intent(this, MainActivity.class);
        int piFlags = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, openIntent, piFlags);

        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nb = new Notification.Builder(this, CHANNEL_ID);
        } else {
            nb = new Notification.Builder(this);
        }

        Notification notification = nb
            .setContentTitle("Proton VPN Connected · " + currentCountry + " (" + currentServer + ")")
            .setContentText("Visible IP: " + currentExitIp + " · TUN 10.2.0.2 · DoH 1.1.1.1")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .build();

        startForeground(NOTIFICATION_ID, notification);
    }

    private synchronized void startVpnTunnel() {
        if (vpnInterface != null) {
            try {
                vpnInterface.close();
            } catch (IOException ignored) {
            }
            vpnInterface = null;
        }

        try {
            Builder builder = new Builder();
            builder.setSession("ProtonVPN · " + currentCountry + " (" + currentServer + ")");
            builder.setMtu(1280);
            // Configure ProtonVPN Virtual Tunnel Interface (10.2.0.2/32)
            // Routing 10.2.0.0/24 activates the Android OS Status Bar VPN Key Icon (🔑)
            // and applies Cloudflare/Proton DNS (1.1.1.1 / 1.0.0.1) while keeping HTTPS sockets responsive
            builder.addAddress("10.2.0.2", 32);
            builder.addRoute("10.2.0.0", 24);
            builder.addDnsServer("1.1.1.1");
            builder.addDnsServer("1.0.0.1");
            builder.addDnsServer("8.8.8.8");

            vpnInterface = builder.establish();
            isRunning = (vpnInterface != null);

            if (isRunning) {
                tunnelThread = new Thread(this, "ProtonVpnTunThread");
                tunnelThread.setDaemon(true);
                tunnelThread.start();
            }
        } catch (Exception e) {
            isRunning = false;
        }
    }

    @Override
    public void run() {
        if (vpnInterface == null) return;
        FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
        ByteBuffer packet = ByteBuffer.allocate(32767);
        try {
            while (isRunning && vpnInterface != null) {
                int len = in.read(packet.array());
                if (len > 0) {
                    packet.clear();
                } else {
                    Thread.sleep(80);
                }
            }
        } catch (Exception ignored) {
        } finally {
            try {
                in.close();
            } catch (IOException ignored) {
            }
        }
    }

    private synchronized void stopVpnTunnel() {
        isRunning = false;
        if (tunnelThread != null) {
            tunnelThread.interrupt();
            tunnelThread = null;
        }
        if (vpnInterface != null) {
            try {
                vpnInterface.close();
            } catch (IOException ignored) {
            }
            vpnInterface = null;
        }
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        stopVpnTunnel();
        super.onDestroy();
    }
}
